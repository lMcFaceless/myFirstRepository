package com.example.listshowcase;

import android.app.Activity;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ListActivity
{
    String[] data = new String[] { };
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                data);
        setListAdapter(adapter);
    }

    @Override
    protected void onListItemClick(ListView l, View view,
                                   int position, long id) {
        String item;
        item = (String) getListAdapter().getItem(position);
        Toast.makeText(this, item + " выбран",
                Toast.LENGTH_SHORT).show();
    }
}